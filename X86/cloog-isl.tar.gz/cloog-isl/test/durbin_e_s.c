/* Generated from ./durbin_e_s.cloog by CLooG 0.18.1-2-g43fc508 gmp bits in 0.00s. */
S4(1,0,0);
S7(1,0,0);
S8(1,0,3);
for (i=2;i<=9;i++) {
  S2(i,-7,0);
  for (j=-7;j<=i-9;j++) {
    S3(i,j,1);
  }
  S6(i,(i-9),2);
  S8(i,0,3);
  for (j=1;j<=i-1;j++) {
    S5(i,j,3);
  }
}
S2(10,-7,0);
for (j=-7;j<=1;j++) {
  S3(10,j,1);
}
S6(10,1,2);
for (j=1;j<=9;j++) {
  S5(10,j,3);
  S1(10,j,4);
}
S1(10,10,4);
