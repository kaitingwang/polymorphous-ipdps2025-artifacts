/* Generated from ../../../git/cloog/test/infinite4.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.00s. */
for (;;i++) {
  S1(i) ;
}
