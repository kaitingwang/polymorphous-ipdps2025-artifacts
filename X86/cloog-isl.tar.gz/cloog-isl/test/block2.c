/* Generated from /home/skimo/git/cloog/test/block2.cloog by CLooG 0.14.0-302-g309b32c gmp bits in 0.01s. */
for (c0=0;c0<=9;c0++) {
  S1(c0,1);
  S3(c0,1);
  S2(c0,1);
}
