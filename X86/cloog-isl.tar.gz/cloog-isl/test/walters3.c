/* Generated from ./walters3.cloog by CLooG 0.18.1-2-g43fc508 gmp bits in 0.00s. */
for (j=2;j<=8;j++) {
  if (j%2 == 0) {
    S1(j,(j/2),(j/2));
    S2(j,(j/2),(j/2));
  }
}
S2(10,5,5);
