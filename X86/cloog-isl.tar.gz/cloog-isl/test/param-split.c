/* Generated from ../test/param-split.cloog by CLooG 0.19.0-6faa51a gmp bits in 0.00s. */
if (M <= -1) {
  S2(0);
}
for (i=0;i<=M;i++) {
  S1(i);
  if (i == 0) {
    S2(i);
  }
}
