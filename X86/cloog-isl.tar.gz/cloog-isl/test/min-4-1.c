/* Generated from ../../../git/cloog/test/min-4-1.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.01s. */
if ((M >= -N) && (M >= -O) && (N >= 0) && (N >= -O)) {
  for (i=max(-M,-N);i<=min(N,O);i++) {
    S1(i) ;
  }
}
