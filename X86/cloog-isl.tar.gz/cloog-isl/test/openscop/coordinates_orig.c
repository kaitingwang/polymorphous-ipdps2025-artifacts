#pragma scop
for (i = 0; i < 42; i++) {
  S1(i);
}
#pragma endscop
