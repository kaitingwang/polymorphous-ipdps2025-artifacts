/* Generated from ../../../git/cloog/test/isl/mod3.cloog by CLooG 0.14.0-325-g62da9f7 gmp bits in 0.02s. */
for (i=max(0,32*h0-1991);i<=min(999,32*h0+31);i++) {
  if ((63*i+32*h0+31)%64 <= 62) {
    for (j=0;j<=999;j++) {
      S1(i,j);
    }
  }
}
