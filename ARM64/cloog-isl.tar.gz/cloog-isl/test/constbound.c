/* Generated from /home/skimo/git/cloog/test/constbound.cloog by CLooG 0.14.0-170-g72daac3 gmp bits in 0.01s. */
for (t0=0;t0<=199;t0++) {
  for (t2=50*t0;t2<=50*t0+24;t2++) {
    for (t3=0;t3<=t2;t3++) {
      S1(t0,t2,t3);
    }
  }
  for (t2=50*t0+25;t2<=50*t0+49;t2++) {
    for (t3=0;t3<=t2;t3++) {
      S2(t0,t2,t3);
    }
  }
}
