/* Generated from ../../../git/cloog/test/stride4.cloog by CLooG 0.16.0-10-g13c6274 gmp bits in 0.00s. */
if ((t >= 0) && (t <= 15)) {
  for (i0=t;i0<=99;i0+=16) {
    S1(i0,t);
  }
}
