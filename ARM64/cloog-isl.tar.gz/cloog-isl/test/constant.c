/* Generated from ../../../git/cloog/test/constant.cloog by CLooG 0.14.0-333-g4442dac gmp bits in 0.01s. */
for (c2=0;c2<=min(1023,M+1024);c2++) {
  S1(c2);
  S3(c2);
}
for (c2=max(0,M+1025);c2<=1023;c2++) {
  S2(c2);
  S3(c2);
}
for (c1=0;c1<=min(1023,M+1024);c1++) {
  S4(c1);
  S6(c1);
}
for (c1=max(0,M+1025);c1<=1023;c1++) {
  S5(c1);
  S6(c1);
}
