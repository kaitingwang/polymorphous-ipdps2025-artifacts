/* Generated from ./reservoir/stride2.cloog by CLooG 0.18.1-2-g43fc508 gmp bits in 0.00s. */
if (M >= 2) {
  for (c2=2;c2<=M;c2+=7) {
    S1(c2,((c2-2)/7));
  }
}
