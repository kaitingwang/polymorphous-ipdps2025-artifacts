/* Generated from /home/skimo/git/cloog/test/lex.cloog by CLooG 0.14.0-234-g330f397 gmp bits in 0.00s. */
for (c1=0;c1<=10;c1++) {
  S2(c1);
  S1(c1);
}
