/* Generated from ./stride2.cloog by CLooG 0.18.1-2-g43fc508 gmp bits in 0.00s. */
for (c1=3;c1<=100;c1+=3) {
  if (c1 == 27) {
    S1(27);
  }
  S2(c1,(c1/3));
}
