/* Generated from ../../../git/cloog/test/iftest.cloog by CLooG 0.14.0-245-gd8c1718 gmp bits in 0.00s. */
if (n >= 1) {
  for (i=1;i<=n;i++) {
    S1(i);
  }
}
